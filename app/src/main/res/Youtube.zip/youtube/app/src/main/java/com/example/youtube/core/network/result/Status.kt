package com.example.youtube.core.network.result

enum class Status {
    SUCCESS, ERROR, LOADING
}