package com.example.youtube.utils

object Const {
    const val part = "snippet, contentDetails"
    const val channelId = "UCQUCjrISpZyBy16Zyl2Uqvg"
}